export const six = 6;
